#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import datetime
import re
import argparse

# 解決 Windows 繁體中文環境列印 Unicode 字元（如 emoji）時崩潰的問題
if sys.platform.startswith('win'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        pass

HOME_DIR = os.path.expanduser("~")
MEM_DIR = os.path.join(HOME_DIR, "self-improving")
HOT_FILE = os.path.join(MEM_DIR, "memory.md")
INDEX_FILE = os.path.join(MEM_DIR, "index.md")
HEARTBEAT_FILE = os.path.join(MEM_DIR, "heartbeat-state.md")
CORRECTIONS_FILE = os.path.join(MEM_DIR, "corrections.md")
REFLECTIONS_FILE = os.path.join(MEM_DIR, "reflections.md")

PROJECTS_DIR = os.path.join(MEM_DIR, "projects")
DOMAINS_DIR = os.path.join(MEM_DIR, "domains")
ARCHIVE_DIR = os.path.join(MEM_DIR, "archive")

def get_timestamp():
    return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00")

def init_memory():
    # 建立目錄結構
    for d in [MEM_DIR, PROJECTS_DIR, DOMAINS_DIR, ARCHIVE_DIR]:
        if not os.path.exists(d):
            os.makedirs(d)
            print(f"✨ 建立資料夾: {d}")
            
    # 建立 HOT 記憶體檔案
    if not os.path.exists(HOT_FILE):
        with open(HOT_FILE, "w", encoding="utf-8") as f:
            f.write("# HOT Memory\n\n此檔案包含小於等於 100 行的最核心全域偏好與指令原則。每次對話皆會載入此偏好。\n\n## Global Preferences\n- 答覆應保持事實客觀，語氣簡潔，避免冗長或重複的說明。\n")
        print(f"📝 建立 HOT 記憶檔: {HOT_FILE}")
        
    # 建立 index.md
    if not os.path.exists(INDEX_FILE):
        with open(INDEX_FILE, "w", encoding="utf-8") as f:
            f.write("# Memory Index\n\n記錄所有記憶分類與對應檔案行數。\n\n- HOT Memory: memory.md\n- WARM Projects: projects/\n- WARM Domains: domains/\n- COLD Archive: archive/\n")
        print(f"📝 建立索引檔: {INDEX_FILE}")
        
    # 建立 heartbeat-state.md
    if not os.path.exists(HEARTBEAT_FILE):
        with open(HEARTBEAT_FILE, "w", encoding="utf-8") as f:
            f.write("# Heartbeat State\n\n記錄記憶維護的心跳狀態、衰退、超限重整日誌。\n\n- Last Run: N/A\n- Status: OK\n")
        print(f"📝 建立維護狀態檔: {HEARTBEAT_FILE}")
        
    # 建立 corrections.md
    if not os.path.exists(CORRECTIONS_FILE):
        with open(CORRECTIONS_FILE, "w", encoding="utf-8") as f:
            f.write("# Corrections Log\n\n記錄最近 50 次使用者的明確訂正與偏好修正。\n\n")
        print(f"📝 建立修正日誌: {CORRECTIONS_FILE}")
        
    # 建立 reflections.md
    if not os.path.exists(REFLECTIONS_FILE):
        with open(REFLECTIONS_FILE, "w", encoding="utf-8") as f:
            f.write("# Reflections Log\n\n記錄開發過程中的自我反思與總結。\n\n")
        print(f"📝 建立反思日誌: {REFLECTIONS_FILE}")
        
    print("🎉 Self-Improving 永久記憶庫初始化成功！")

def ensure_initialized():
    if not os.path.exists(MEM_DIR):
        init_memory()

def rotate_log_file(filepath, max_entries=50):
    if not os.path.exists(filepath):
        return
        
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
        
    # 解析出所有的條目。條目通常以 "- [timestamp]" 或 "##" 開頭
    # 我們可以簡單地按 "- [" 來切分
    header = []
    entries = []
    current_entry = []
    
    for line in lines:
        if line.startswith("#"):
            header.append(line)
        elif line.strip().startswith("- ["):
            if current_entry:
                entries.append("".join(current_entry))
                current_entry = []
            current_entry.append(line)
        else:
            if current_entry:
                current_entry.append(line)
            else:
                header.append(line)
                
    if current_entry:
        entries.append("".join(current_entry))
        
    # 如果條目超過最大限制，進行截斷（保留最近的）
    if len(entries) > max_entries:
        pruned_entries = entries[-max_entries:]
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("".join(header))
            f.write("\n")
            f.write("\n".join(pruned_entries))
        print(f"♻️ 記錄已自動輪替，{os.path.basename(filepath)} 僅保留最近 {max_entries} 筆紀錄。")

def add_correction(args):
    ensure_initialized()
    timestamp = get_timestamp()
    
    entry = f"- [{timestamp}] CONTEXT: {args.context}\n  CORRECTION: {args.correction}\n  LESSON: {args.lesson}\n\n"
    
    with open(CORRECTIONS_FILE, "a", encoding="utf-8") as f:
        f.write(entry)
    print(f"✅ 成功寫入修正日誌: {CORRECTIONS_FILE}")
    
    rotate_log_file(CORRECTIONS_FILE, max_entries=50)

def add_reflection(args):
    ensure_initialized()
    timestamp = get_timestamp()
    
    entry = f"- [{timestamp}] CONTEXT: {args.context}\n  REFLECTION: {args.reflection}\n  LESSON: {args.lesson}\n\n"
    
    with open(REFLECTIONS_FILE, "a", encoding="utf-8") as f:
        f.write(entry)
    print(f"✅ 成功寫入反思日誌: {REFLECTIONS_FILE}")
    
    rotate_log_file(REFLECTIONS_FILE, max_entries=50)

def count_file_lines(filepath):
    if not os.path.exists(filepath):
        return 0
    with open(filepath, "r", encoding="utf-8") as f:
        return sum(1 for _ in f)

def get_stats():
    ensure_initialized()
    
    # 統計 HOT memory.md 的行數與條目數
    hot_lines = count_file_lines(HOT_FILE)
    
    # 統計 projects 目錄下的檔案數與大小
    project_files = [f for f in os.listdir(PROJECTS_DIR) if os.path.isfile(os.path.join(PROJECTS_DIR, f))]
    domain_files = [f for f in os.listdir(DOMAINS_DIR) if os.path.isfile(os.path.join(DOMAINS_DIR, f))]
    archive_files = [f for f in os.listdir(ARCHIVE_DIR) if os.path.isfile(os.path.join(ARCHIVE_DIR, f))]
    
    # 讀取 corrections.md 與 reflections.md 的最近記錄數
    corr_count = 0
    if os.path.exists(CORRECTIONS_FILE):
        with open(CORRECTIONS_FILE, "r", encoding="utf-8") as f:
            corr_count = len(re.findall(r"- \[\d{4}-\d{2}-\d{2}", f.read()))
            
    refl_count = 0
    if os.path.exists(REFLECTIONS_FILE):
        with open(REFLECTIONS_FILE, "r", encoding="utf-8") as f:
            refl_count = len(re.findall(r"- \[\d{4}-\d{2}-\d{2}", f.read()))
            
    print("📊 ===== Self-Improving 永久分層記憶體狀態 =====")
    print(f"\n🔥 HOT 層 (常駐載入):")
    print(f"  memory.md: 行數 {hot_lines} 行 (限制 ≤ 100 行)")
    
    print(f"\n🌤️ WARM 層 (按需載入):")
    print(f"  projects/ (專案級偏好): {len(project_files)} 個專案檔案")
    for pf in project_files:
        p_lines = count_file_lines(os.path.join(PROJECTS_DIR, pf))
        print(f"    - {pf}: {p_lines} 行 (限制 ≤ 200 行)")
        
    print(f"  domains/ (領域級偏好): {len(domain_files)} 個領域檔案")
    for df in domain_files:
        d_lines = count_file_lines(os.path.join(DOMAINS_DIR, df))
        print(f"    - {df}: {d_lines} 行 (限制 ≤ 200 行)")
        
    print(f"\n❄️ COLD 層 (封存備份):")
    print(f"  archive/ (冷封存偏好): {len(archive_files)} 個封存檔案")
    
    print(f"\n📈 近期活動統計:")
    print(f"  已記錄的修正 (Corrections): {corr_count} 筆")
    print(f"  已記錄的反思 (Reflections): {refl_count} 筆")
    
    # 檢查維護時間
    last_hb = "無紀錄"
    if os.path.exists(HEARTBEAT_FILE):
        with open(HEARTBEAT_FILE, "r", encoding="utf-8") as f:
            match = re.search(r"- Last Run:\s*(.*?)$", f.read(), re.MULTILINE)
            if match:
                last_hb = match.group(1).strip()
    print(f"  最後心跳維護時間: {last_hb}")

def run_heartbeat():
    ensure_initialized()
    timestamp = get_timestamp()
    print("💓 啟動自我反思與記憶體心跳維護 (Heartbeat Check)...")
    
    # 讀取最近的修正與反思以分析是否有重複發生的模式
    lessons = []
    for filepath in [CORRECTIONS_FILE, REFLECTIONS_FILE]:
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
                # 抓取所有 LESSON: 後面的字句
                matches = re.findall(r"LESSON:\s*(.*?)$", content, re.MULTILINE)
                lessons.extend(matches)
                
    # 尋找重複出現的關鍵字 (簡單的頻率統計與相似性推薦)
    from collections import Counter
    words = []
    for lesson in lessons:
        # 分割成單字並過濾掉常見停用詞（中文/英文）
        for w in re.findall(r"\w+", lesson.lower()):
            if len(w) > 1 and w not in ["the", "and", "for", "with", "this", "that", "should", "always", "never", "應先", "執行", "修正", "使用"]:
                words.append(w)
                
    common_patterns = Counter(words).most_common(5)
    
    maintenance_notes = "執行例行記憶體重整與重複比對。"
    if common_patterns:
        maintenance_notes += f" 偵測到近期關鍵重複模式: {', '.join([f'{w[0]} ({w[1]}次)' for w in common_patterns])}。"
        print(f"🔍 偵測到近期可能重複的模式: {common_patterns}")
        print("💡 建議：若上述某個主題在 7 天內重複了 3 次，可將其正式寫入 memory.md (HOT) 中以避免再次犯錯。")
        
    # 檢查 HOT memory.md 的行數，若超過 100 行則警示
    hot_lines = count_file_lines(HOT_FILE)
    if hot_lines > 100:
        print(f"⚠️ 警告: HOT 記憶檔 ({HOT_FILE}) 行數為 {hot_lines} 行，已超出 100 行限制！")
        print("💡 建議：請將近期不常用的項目移至 WARM 層的 projects/ 或 domains/。")
        maintenance_notes += " 注意：HOT memory.md 已超出限制，需手動重整降級。"
        
    # 更新 heartbeat-state.md
    with open(HEARTBEAT_FILE, "w", encoding="utf-8") as f:
        f.write(f"# Heartbeat State\n\n記錄記憶維護的心跳狀態、衰退、超限重整日誌。\n\n- Last Run: {timestamp}\n- Status: OK\n- Notes: {maintenance_notes}\n")
        
    print(f"🎉 心跳維護完成。狀態已寫入 {HEARTBEAT_FILE}")

def main():
    parser = argparse.ArgumentParser(description="Self-Improving 永久記憶體管理器")
    subparsers = parser.add_subparsers(dest="command", help="子指令")
    
    # init
    subparsers.add_parser("init", help="初始化 ~/self-improving/ 記憶庫結構")
    
    # correction
    p_corr = subparsers.add_parser("correction", help="手動記錄使用者修正與個人偏好")
    p_corr.add_argument("--context", required=True, help="修正的情境或技術背景")
    p_corr.add_argument("--correction", required=True, help="被糾正的錯誤或原有的不良表現")
    p_corr.add_argument("--lesson", required=True, help="學到的經驗以及未來應該如何改進")
    
    # reflect
    p_refl = subparsers.add_parser("reflect", help="手動記錄自我反思日記")
    p_refl.add_argument("--context", required=True, help="反思的情境或工作階段")
    p_refl.add_argument("--reflection", required=True, help="自己發現的不足或優化機會")
    p_refl.add_argument("--lesson", required=True, help="未來遇到類似情境的具體防錯作法")
    
    # heartbeat
    subparsers.add_parser("heartbeat", help="執行心跳檢查與衰退、合併自動維護")
    
    # stats
    subparsers.add_parser("stats", help="統計各分層記憶體的儲存狀態與行數")
    
    args = parser.parse_args()
    
    if args.command == "init":
        init_memory()
    elif args.command == "correction":
        add_correction(args)
    elif args.command == "reflect":
        add_reflection(args)
    elif args.command == "heartbeat":
        run_heartbeat()
    elif args.command == "stats":
        get_stats()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

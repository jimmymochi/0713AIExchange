---
name: self-improving
description: 分層式自我反思、檢討與永久性偏好記憶體。支援 HOT/WARM/COLD 三層儲存，隨任務動態載入上下文。
---

# Self-Improving + Proactive Agent

本技能實現了一個具有「多層級動態記憶（Tiered Memory）」與「自我反思（Self-Reflection）」機制的永久改進系統。不同於專案層級的日誌，此技能的記憶庫儲存在使用者的家目錄 `~/self-improving/`，能跨專案、跨會話持續發揮作用。

## 記憶分層架構 (Tiered Storage)

所有記憶檔案皆位於 `~/self-improving/` 目錄中：

```
~/self-improving/
├── memory.md          # HOT 層：小於等於 100 行。最核心的全域偏好與硬性規則，每次對話常駐載入。
├── index.md           # 索引層：記錄所有主題分類與記憶條數。
├── heartbeat-state.md # 心跳維護狀態：記錄上一次維護時間、記憶衰退與重整資訊。
├── corrections.md     # 修正日誌：記錄最近 50 次使用者明確做出的訂正。
├── reflections.md     # 反思日誌：記錄 Agent 自我回顧與任務總結的結果。
├── projects/          # WARM 層（專案級）：scoped 到特定專案名稱的偏好，按需載入。
│   └── {project}.md   # 例如 projects/antigravity.md (小於等於 200 行)
├── domains/           # WARM 層（領域級）：特定技術或領域（例如 domains/python.md）偏好，按需載入。
└── archive/           # COLD 層：已衰退或極少使用的記憶封存庫，不佔用常駐上下文。
```

---

## 適用與觸發場景

當偵測到以下訊號時，請自動觸發記憶或反思登錄：

### 1. 使用者修正 (Corrections) -> 登錄至 `corrections.md`
- 當使用者做出糾正：「不對，不是這樣...」、「其實應該是...」、「你弄錯了」。
- 使用者表達個人偏好：「我喜歡你這樣寫...」、「永遠不要做 Y」、「我的程式風格是...」。
- 使用者提醒重複事項：「我之前說過...」、「你怎麼又...」。

### 2. 自我反思 (Self-Reflection) -> 登錄至 `reflections.md`
- 在完成一個階段性的重大任務後（例如實作完一個大組件或修復複雜 bug）。
- 當自己發現輸出的內容不夠完美，並找到具體原因時。
- 反思格式：
  ```
  CONTEXT: [任務類型，如 Building React Component]
  REFLECTION: [自己注意到的優缺點，如 間距計算有偏差，導致畫面稍微擠壓]
  LESSON: [下次如何做得更好，如 顯示給使用者前，先用視覺工具或比例尺自我檢查]
  ```

---

## 動態升級與衰退機制 (Promotion & Decay)

- **升級 (Promotion)**：當某個修正或反思在 **7 天內重複使用了 3 次**，自動將其提煉並升級至 **HOT 層 (`memory.md`)**。
- **衰退 (Decay)**：
  - **HOT 降級 WARM**：若某條 HOT 偏好 **30 天內未被調用**，降級至 WARM 層（依據分類放入 `projects/` 或 `domains/`）。
  - **WARM 降級 COLD (Archive)**：若某條 WARM 偏好 **90 天內未被調用**，封存至 COLD 層 (`archive/`)。

---

## 記憶維護工具 (reflect.py CLI)

本技能提供了一個強大的 Python 維護腳本，可用於本地自動初始化、登錄修正、記錄反思、執行三層記憶調度重整（心跳維護）。

### 1. 初始化家目錄
```bash
python ~/.gemini/config/plugins/science/skills/self-improving/scripts/reflect.py init
```

### 2. 登錄使用者修正 (Correction)
```bash
python ~/.gemini/config/plugins/science/skills/self-improving/scripts/reflect.py correction \
  --context "Git authentication" \
  --correction "Windows 環境下 git push 之前必須先確保 credential.helper 已設定，否則會卡住" \
  --lesson "在執行 git 操作前先確認 credential 狀態"
```

### 3. 登錄自我反思 (Reflection)
```bash
python ~/.gemini/config/plugins/science/skills/self-improving/scripts/reflect.py reflect \
  --context "Building Web App" \
  --reflection "未先檢查 npm 依賴直接執行啟動，導致找不到模組錯誤" \
  --lesson "新增任何元件或套用範本後，應先執行 npm install 確保相依性完整"
```

### 4. 心跳維護與衰退整理 (Heartbeat / Compaction)
自動執行記憶的重複合併、超限壓縮、過期條目衰退至 WARM/COLD：
```bash
python ~/.gemini/config/plugins/science/skills/self-improving/scripts/reflect.py heartbeat
```

### 5. 查詢記憶體狀態與統計
```bash
python ~/.gemini/config/plugins/science/skills/self-improving/scripts/reflect.py stats
```

---

## 核心行為規範

1. **命名空間隔離 (Namespace Isolation)**：專案專屬偏好應嚴格限制在 `projects/{project_name}.md`。只有全局性、極高頻的偏好才能晉升至全域 `memory.md` (HOT)。
2. **安全邊界 (Security Boundaries)**：**嚴禁**在任何記憶層級中儲存金鑰、憑證、個人隱私資料（如地址、電話）、第三方敏感商業機密或健康資料。
3. **透明引用 (Transparency)**：每一次由於此技能記憶而改變行為時，請在回覆中主動說明：「*（已套用偏好設定，來源：~/self-improving/memory.md:12）*」，讓使用者知道為什麼你的表現越來越契合他。

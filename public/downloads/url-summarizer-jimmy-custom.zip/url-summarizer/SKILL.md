---
name: url-summarizer
description: Fetches webpage contents from a URL, strips HTML noise, and allows the Agent to generate a high-quality Traditional Chinese summary.
---

# url-summarizer

本技能是專用的**網頁文章與學術資訊摘要助理 (url-summarizer)**。它能將任意公開網頁、技術部落格或線上文獻，快速下載並過濾掉 HTML 雜訊，儲存至本地 Markdown 檔案中。同時，它內建了高效、乾淨的 PDF 生成引擎，能將結構化中文摘要直接輸出為排版精美的 PDF 報告。

---

## 核心功能與工具

本技能包含兩個核心自動化工具：

1. **網頁擷取工具 (`summarize.py`)**: 下載公開網頁並過濾 HTML 標籤、JS、CSS，儲存為乾淨的 Markdown 格式純文字。
2. **乾淨 PDF 產出工具 (`to_pdf.py`)**: 將 Markdown 格式的摘要或擷取內容轉換成具有精美排版、頁碼、專業色塊與「微軟正黑體」字型支援的乾淨 PDF 檔案。

---

## 使用指南

### 1. 抓取網頁內容
在 Terminal 中執行以下指令以擷取網頁純文字：
```powershell
py C:\Users\jimmy\.gemini\config\plugins\science\skills\url-summarizer\scripts\summarize.py "https://example.com/article" "C:\Users\jimmy\Desktop\article.md"
```

### 2. 轉換成乾淨的 PDF 檔案
使用內建的轉換引擎，將 Markdown 格式的摘要檔案轉換成 PDF 檔案：
```powershell
py C:\Users\jimmy\.gemini\config\plugins\science\skills\url-summarizer\scripts\to_pdf.py "C:\Users\jimmy\Desktop\article.md" "C:\Users\jimmy\Desktop\article_clean.pdf"
```

---

## PDF 排版規格
本技能產出的 PDF 檔案符合以下專業排版規格：
- **字型支援**: 完整支援 Windows 系統字型「微軟正黑體 (Microsoft JhengHei)」，完美避免繁體中文字元缺字或亂碼。
- **標題設計**: 標題 `H1`、`H2` 與 `H3` 皆採用粗體字與專業商務色彩（深藍/天藍），`H2` 標題左側附帶精美的垂直點綴線。
- **列表與引用**: 清單項目自動排版並附帶小圓點；引言 (`>`) 左側自動加上灰色直邊線。
- **中介資料區塊 (Metadata)**: 在檔案頂端自動加上淺藍色背景與垂直粗邊線的 Metadata 區塊，標示來源網址與建立日期。
- **自動分頁與頁碼**: 內建長文字段落測試，當單頁剩餘高度不足時會自動換頁，並在每一頁底部精確標記「Page X of Y」與上方的精美頁首底線。

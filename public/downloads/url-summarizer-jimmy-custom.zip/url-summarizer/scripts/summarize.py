# URL Fetcher and Parser for url-summarizer Skill

import sys
import urllib.request
import urllib.parse
import json
import re

# Force UTF-8 output encoding for Windows Terminal compatibility
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def fetch_url(url, output_path):
    """
    Fetches the public webpage, strips raw HTML tags, and saves clean text/markdown to output_path.
    """
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    )
    
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            html = response.read().decode("utf-8", errors="ignore")
            
            # Simple regex to strip script, style, and HTML tags
            html = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', html, flags=re.IGNORECASE)
            html = re.sub(r'<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>', '', html, flags=re.IGNORECASE)
            text = re.sub(r'<[^>]+>', ' ', html)
            
            # Clean up extra whitespace and newlines
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            clean_text = "\n".join(lines)
            
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(f"Source URL: {url}\n\n")
                f.write(clean_text)
                
            print(f"🟢 Successfully fetched and parsed URL.")
            print(f"📂 Extracted text saved to: {output_path}")
            return True
    except Exception as e:
        print(f"❌ Error: Webpage fetch failed: {str(e)}", file=sys.stderr)
        return False

def main():
    if len(sys.argv) < 3:
        print("Usage: py summarize.py <url> <output_path>")
        sys.exit(1)
        
    url = sys.argv[1]
    out_path = sys.argv[2]
    
    success = fetch_url(url, out_path)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()

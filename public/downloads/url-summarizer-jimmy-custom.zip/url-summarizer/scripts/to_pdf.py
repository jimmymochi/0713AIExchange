#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import datetime
import re
import fitz

# 解決 Windows 繁體中文環境列印 Unicode 字元時崩潰的問題
if sys.platform.startswith('win'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        pass

REG_FONT_PATH = r"C:\Windows\Fonts\msjh.ttc"
BOLD_FONT_PATH = r"C:\Windows\Fonts\msjhbd.ttc"

class PDFRenderer:
    def __init__(self, output_path):
        self.output_path = output_path
        self.doc = fitz.open()
        self.page = None
        self.y_pos = 60
        self.margin_left = 50
        self.margin_right = 545
        self.margin_top = 60
        self.margin_bottom = 780
        self.page_width = 595
        self.page_height = 842
        
        # 建立第一頁
        self.add_page()
        
    def add_page(self):
        self.page = self.doc.new_page(width=self.page_width, height=self.page_height)
        
        # 註冊微軟正黑體（一般與粗體）
        if os.path.exists(REG_FONT_PATH):
            self.page.insert_font(fontname="msjh", fontfile=REG_FONT_PATH)
        if os.path.exists(BOLD_FONT_PATH):
            self.page.insert_font(fontname="msjhbd", fontfile=BOLD_FONT_PATH)
            
        self.y_pos = self.margin_top
        
    def draw_header_footer(self):
        # 在每一頁繪製頁尾頁碼（可選，在 save 時統一繪製最精確）
        pass

    def add_text_block(self, text, block_type='p', metadata=None):
        """
        以極佳的排版格式加入一段文字區塊，支援自動換頁
        """
        # 設定不同區塊類別的字型大小、字型、顏色與間距
        fs = 11
        font = "msjh"
        color = (0.176, 0.216, 0.282) # #2D3748
        space_after = 12
        line_height = 16 # 用於估算
        
        l_margin = self.margin_left
        r_margin = self.margin_right
        
        if block_type == 'h1':
            fs = 18
            font = "msjhbd"
            color = (0.102, 0.212, 0.365) # #1A365D
            space_after = 16
        elif block_type == 'h2':
            fs = 14
            font = "msjhbd"
            color = (0.169, 0.424, 0.690) # #2B6CB0
            space_after = 14
            l_margin = self.margin_left + 8
        elif block_type == 'h3':
            fs = 12
            font = "msjhbd"
            color = (0.290, 0.333, 0.408) # #4A5568
            space_after = 10
        elif block_type == 'bullet':
            fs = 11
            font = "msjh"
            l_margin = self.margin_left + 15
            space_after = 8
        elif block_type == 'quote':
            fs = 10.5
            font = "msjh"
            color = (0.443, 0.502, 0.588) # #718096
            l_margin = self.margin_left + 15
            space_after = 10
        elif block_type == 'code':
            fs = 9.5
            font = "msjh" # Fallback to msjh for CJK inside code
            l_margin = self.margin_left + 10
            space_after = 10
        elif block_type == 'meta':
            fs = 9.5
            font = "msjh"
            color = (0.169, 0.424, 0.690)
            space_after = 18
            l_margin = self.margin_left + 10
            
        # 處理單行過長或換頁邏輯
        # 建立測試用的 rect
        test_rect = fitz.Rect(l_margin, self.y_pos, r_margin, self.margin_bottom)
        
        # 執行首次渲染測試
        res = self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=color, align=0)
        
        # 如果 res < 0，代表此頁剩餘高度不夠放
        if res < 0:
            self.add_page()
            # 重新定位與渲染
            test_rect = fitz.Rect(l_margin, self.y_pos, r_margin, self.margin_bottom)
            res = self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=color, align=0)
            
        # 計算實際耗費的高度
        height_used = test_rect.height - res if res >= 0 else test_rect.height + abs(res)
        
        # 繪製特殊修飾元件（例如 h2 的左側粗線、blockquote 的左側灰線、meta 的背景色塊）
        if block_type == 'h2':
            # 在 h2 左側畫一條藍色的垂直短線
            self.page.draw_line(
                fitz.Point(self.margin_left, self.y_pos + 2),
                fitz.Point(self.margin_left, self.y_pos + height_used - 2),
                color=(0.169, 0.424, 0.690),
                width=4
            )
        elif block_type == 'quote':
            # 在 blockquote 左側畫一條灰色的垂直長線
            self.page.draw_line(
                fitz.Point(self.margin_left + 5, self.y_pos),
                fitz.Point(self.margin_left + 5, self.y_pos + height_used),
                color=(0.796, 0.835, 0.878),
                width=3
            )
        elif block_type == 'bullet':
            # 在 bullet 前方繪製圓點 •
            self.page.insert_text(
                fitz.Point(self.margin_left + 2, self.y_pos + 10),
                "•",
                fontname="msjhbd",
                fontsize=12,
                color=(0.169, 0.424, 0.690)
            )
        elif block_type == 'meta':
            # 繪製淺藍色背景色塊與左邊藍色垂直邊線
            bg_rect = fitz.Rect(self.margin_left, self.y_pos - 4, self.margin_right, self.y_pos + height_used + 4)
            self.page.draw_rect(bg_rect, color=None, fill=(0.92, 0.96, 1.0), fill_opacity=1.0)
            self.page.draw_line(
                fitz.Point(self.margin_left, self.y_pos - 4),
                fitz.Point(self.margin_left, self.y_pos + height_used + 4),
                color=(0.192, 0.509, 0.807),
                width=4
            )
            # 因為背景色塊會覆蓋文字，我們必須在畫完背景後重新填入文字
            self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=color, align=0)
            
        elif block_type == 'code':
            # 繪製淺灰色背景色塊
            bg_rect = fitz.Rect(self.margin_left, self.y_pos - 4, self.margin_right, self.y_pos + height_used + 4)
            self.page.draw_rect(bg_rect, color=None, fill=(0.968, 0.976, 0.984), fill_opacity=1.0)
            self.page.draw_rect(bg_rect, color=(0.886, 0.910, 0.941), width=1)
            self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=(0.176, 0.216, 0.282), align=0)
            
        self.y_pos += height_used + space_after

    def save(self):
        # 統一在每一頁的最下方繪製頁碼與輕量頁眉線
        page_count = self.doc.page_count
        for idx in range(page_count):
            p = self.doc[idx]
            # 頁眉線與標題
            p.draw_line(
                fitz.Point(self.margin_left, 45),
                fitz.Point(self.margin_right, 45),
                color=(0.886, 0.910, 0.941),
                width=1
            )
            p.insert_text(
                fitz.Point(self.margin_left, 38),
                "網頁摘要助理 (url-summarizer) 結構化報告",
                fontname="msjh",
                fontsize=8.5,
                color=(0.443, 0.502, 0.588)
            )
            
            # 頁碼
            p.insert_text(
                fitz.Point(self.margin_right - 30, self.margin_bottom + 25),
                f"Page {idx + 1} of {page_count}",
                fontname="msjh",
                fontsize=9,
                color=(0.443, 0.502, 0.588)
            )
            
        self.doc.save(self.output_path)
        self.doc.close()
        print(f"🎉 乾淨的 PDF 已成功儲存至: {self.output_path}")

def parse_markdown_to_blocks(md_content):
    blocks = []
    lines = md_content.splitlines()
    
    # 簡單的狀態機來解析列表與程式區塊
    in_code_block = False
    code_buffer = []
    
    for line in lines:
        stripped = line.strip()
        
        # 處理程式區塊
        if stripped.startswith("```"):
            if in_code_block:
                blocks.append(('code', "\n".join(code_buffer)))
                code_buffer = []
                in_code_block = False
            else:
                in_code_block = True
            continue
            
        if in_code_block:
            code_buffer.append(line)
            continue
            
        # 空行忽略
        if not stripped:
            continue
            
        # 標題
        if stripped.startswith("# "):
            blocks.append(('h1', stripped[2:]))
        elif stripped.startswith("## "):
            blocks.append(('h2', stripped[3:]))
        elif stripped.startswith("### "):
            blocks.append(('h3', stripped[4:]))
        # 引用
        elif stripped.startswith(">"):
            blocks.append(('quote', stripped[1:].strip()))
        # 列表
        elif stripped.startswith("- ") or stripped.startswith("* "):
            blocks.append(('bullet', stripped[2:]))
        elif re.match(r"^\d+\.\s", stripped):
            match = re.match(r"^\d+\.\s(.*)", stripped)
            blocks.append(('bullet', match.group(1)))
        # 來源網址 metadata 色塊
        elif stripped.lower().startswith("source url:") or stripped.lower().startswith("來源網址:"):
            blocks.append(('meta', stripped))
        else:
            # 一般段落，清除一些行內 bold (**) 的符號，保持 PDF 乾淨
            clean_line = re.sub(r"\*\*(.*?)\*\*", r"\1", stripped)
            blocks.append(('p', clean_line))
            
    return blocks

def main():
    if len(sys.argv) < 3:
        print("Usage: py to_pdf.py <input_markdown_path> <output_pdf_path>")
        sys.exit(1)
        
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    if not os.path.exists(input_path):
        print(f"❌ Error: 找不到輸入檔案: {input_path}")
        sys.exit(1)
        
    with open(input_path, "r", encoding="utf-8") as f:
        md_content = f.read()
        
    blocks = parse_markdown_to_blocks(md_content)
    
    renderer = PDFRenderer(output_path)
    
    for block_type, text in blocks:
        renderer.add_text_block(text, block_type)
        
    renderer.save()
    sys.exit(0)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import argparse
import re
import fitz

# Ensure standard UTF-8 output on Windows
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except AttributeError:
    pass

REG_FONT_PATH = r"C:\Windows\Fonts\msjh.ttc"
BOLD_FONT_PATH = r"C:\Windows\Fonts\msjhbd.ttc"

def clean_latex(text):
    """
    Cleans LaTeX mathematical notations into clean Unicode equivalents.
    """
    translations = {
        r"\phi": "φ", r"\theta": "θ", r"\lambda": "λ", r"\Delta": "Δ", r"\sigma": "σ",
        r"\text{new}": "new", r"\text{N}": "N", r"\text{E}": "E", r"\text{km}": "km", r"\text{ km}": " km",
        r"\bmod": "mod", r"\circ": "°", r"\le": "≤", r"\ge": "≥", r"\rightarrow": "→",
        r"\bullet": "•", r"\cdot": "·", r"\times": "×", r"\_": "_", r"\pm": "±", r"\approx": "≈",
    }
    
    # Strip LaTeX delimiters
    text = text.replace("$$", "").replace("$", "")
    
    # Replace LaTeX commands
    for lat, uni in translations.items():
        text = text.replace(lat, uni)
        
    # Remove remaining LaTeX styling helpers
    text = re.sub(r"\\text\s*\{\s*(.*?)\s*\}", r"\1", text)
    text = re.sub(r"_\{([^}]+)\}", r"_\1", text)
    text = re.sub(r"\^\{([^}]+)\}", r"^\1", text)
    text = text.replace("\\", "")
    return text

def clean_markdown_formatting(text):
    """
    Removes bold markers and standard LaTeX math remnants.
    """
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = clean_latex(text)
    text = text.replace("`", "")
    return text

class PDFRenderer:
    def __init__(self, output_path, font_path=None, margin_left=50, margin_right=545, margin_top=60, margin_bottom=780, header="", footer="", show_page_num=True):
        self.output_path = output_path
        self.doc = fitz.open()
        self.page = None
        self.y_pos = margin_top
        
        self.margin_left = margin_left
        self.margin_right = margin_right
        self.margin_top = margin_top
        self.margin_bottom = margin_bottom
        self.page_width = 595
        self.page_height = 842
        
        self.header_text = header
        self.footer_text = footer
        self.show_page_num = show_page_num
        
        # Font paths
        self.font_path = font_path if font_path and os.path.exists(font_path) else REG_FONT_PATH
        self.bold_font_path = BOLD_FONT_PATH if os.path.exists(BOLD_FONT_PATH) else self.font_path
        
        # Create first page
        self.add_page()
        
    def add_page(self):
        self.page = self.doc.new_page(width=self.page_width, height=self.page_height)
        
        # Register Microsoft JhengHei fonts
        if os.path.exists(self.font_path):
            self.page.insert_font(fontname="msjh", fontfile=self.font_path)
        if os.path.exists(self.bold_font_path):
            self.page.insert_font(fontname="msjhbd", fontfile=self.bold_font_path)
            
        self.y_pos = self.margin_top
        
    def add_text_block(self, text, block_type='p'):
        """
        Insects a styled text block into the PDF with page overflow detection.
        """
        if not text or not text.strip():
            return
            
        if self.y_pos >= self.margin_bottom - 20:
            self.add_page()
            
        fs = 11
        font = "msjh"
        color = (0.176, 0.216, 0.282) # #2D3748
        space_after = 12
        
        l_margin = self.margin_left
        r_margin = self.margin_right
        
        if block_type == 'h1':
            fs = 18
            font = "msjhbd"
            color = (0.102, 0.212, 0.365) # #1A365D
            space_after = 16
        elif block_type == 'h2':
            fs = 14
            font = "msjhbd"
            color = (0.169, 0.424, 0.690) # #2B6CB0
            space_after = 14
            l_margin = self.margin_left + 8
        elif block_type == 'h3':
            fs = 12
            font = "msjhbd"
            color = (0.290, 0.333, 0.408) # #4A5568
            space_after = 10
        elif block_type == 'bullet':
            fs = 11
            font = "msjh"
            l_margin = self.margin_left + 15
            space_after = 8
        elif block_type == 'quote':
            fs = 10.5
            font = "msjh"
            color = (0.290, 0.333, 0.408)
            l_margin = self.margin_left + 15
            space_after = 10
        elif block_type == 'code':
            fs = 9.5
            font = "msjh"
            l_margin = self.margin_left + 10
            space_after = 10
            
        # Estimated height calculation to prevent orphans and widows
        import math
        w = r_margin - l_margin
        lines = 0
        for part in text.split('\n'):
            part_len = sum(1.0 if ord(c) > 127 else 0.55 for c in part)
            lines += max(1.0, math.ceil(part_len / (w / fs) if w > 0 else 1))
        estimated_height = lines * (fs * 1.35)
        
        # If the remaining space is not enough and we are not at the top of a page, start on a new page
        if estimated_height > (self.margin_bottom - self.y_pos) and self.y_pos > self.margin_top + 10:
            self.add_page()
            
        # Draw background decorations BEFORE inserting text to avoid text duplication/overlapping
        if block_type == 'quote':
            bg_rect = fitz.Rect(self.margin_left + 5, self.y_pos - 4, self.margin_right, self.y_pos + estimated_height + 4)
            self.page.draw_rect(bg_rect, color=None, fill=(0.95, 0.96, 0.98), fill_opacity=1.0)
            self.page.draw_line(
                fitz.Point(self.margin_left + 5, self.y_pos - 4),
                fitz.Point(self.margin_left + 5, self.y_pos + estimated_height + 4),
                color=(0.443, 0.502, 0.588),
                width=3
            )
        elif block_type == 'code':
            bg_rect = fitz.Rect(self.margin_left, self.y_pos - 4, self.margin_right, self.y_pos + estimated_height + 4)
            self.page.draw_rect(bg_rect, color=None, fill=(0.968, 0.976, 0.984), fill_opacity=1.0)
            self.page.draw_rect(bg_rect, color=(0.886, 0.910, 0.941), width=1)
            
        # Draw text box
        test_rect = fitz.Rect(l_margin, self.y_pos, r_margin, self.margin_bottom)
        res = self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=color, align=0)
        
        # If it still doesn't fit on this page (res < 0), split across multiple pages
        loop_count = 0
        while res < 0 and loop_count < 5:
            self.add_page()
            
            # Draw background on new pages for long quotes or code blocks
            if block_type == 'quote':
                bg_rect = fitz.Rect(self.margin_left + 5, self.y_pos - 4, self.margin_right, self.margin_bottom - 20)
                self.page.draw_rect(bg_rect, color=None, fill=(0.95, 0.96, 0.98), fill_opacity=1.0)
                self.page.draw_line(
                    fitz.Point(self.margin_left + 5, self.y_pos - 4),
                    fitz.Point(self.margin_left + 5, self.margin_bottom - 20),
                    color=(0.443, 0.502, 0.588),
                    width=3
                )
            elif block_type == 'code':
                bg_rect = fitz.Rect(self.margin_left, self.y_pos - 4, self.margin_right, self.margin_bottom - 20)
                self.page.draw_rect(bg_rect, color=None, fill=(0.968, 0.976, 0.984), fill_opacity=1.0)
                self.page.draw_rect(bg_rect, color=(0.886, 0.910, 0.941), width=1)
                
            test_rect = fitz.Rect(l_margin, self.y_pos, r_margin, self.margin_bottom)
            res = self.page.insert_textbox(test_rect, text, fontname=font, fontsize=fs, color=color, align=0)
            loop_count += 1
            
        height_used = test_rect.height - res if res >= 0 else test_rect.height
        if height_used <= 0:
            height_used = fs * 1.3
        
        # Draw side decorations for special blocks after text is placed
        if block_type == 'h2':
            self.page.draw_line(
                fitz.Point(self.margin_left, self.y_pos + 2),
                fitz.Point(self.margin_left, self.y_pos + height_used - 2),
                color=(0.169, 0.424, 0.690),
                width=4
            )
        elif block_type == 'bullet':
            self.page.insert_text(
                fitz.Point(self.margin_left + 2, self.y_pos + 9),
                "•",
                fontname="msjhbd",
                fontsize=12,
                color=(0.169, 0.424, 0.690)
            )
            
        self.y_pos += height_used + space_after

    def add_table_block(self, table_rows):
        """
        Renders a cleanly formatted grid table in the PDF, eliminating Markdown pipe symbols.
        Supports automatic splitting across multiple pages with header repetition.
        """
        if not table_rows:
            return
            
        # Parse data
        parsed_rows = []
        for row in table_rows:
            cells = [clean_markdown_formatting(c.strip()) for c in row.split('|')[1:-1]]
            parsed_rows.append(cells)
            
        if not parsed_rows:
            return
            
        num_cols = len(parsed_rows[0])
        col_width = (self.margin_right - self.margin_left) / num_cols
        row_height = 24
        
        # Check if table fits on current page. If the page is almost full (e.g., less than 3 rows fit), break early.
        if self.y_pos + (3 * row_height) > self.margin_bottom:
            self.add_page()
            
        # Draw outer top border on first page
        self.page.draw_line(
            fitz.Point(self.margin_left, self.y_pos),
            fitz.Point(self.margin_right, self.y_pos),
            color=(0.102, 0.212, 0.365),
            width=2
        )
        
        # Render table row by row
        for r_idx, row in enumerate(parsed_rows):
            is_header = (r_idx == 0)
            
            # Check if this row fits on the current page
            if self.y_pos + row_height > self.margin_bottom:
                self.add_page()
                
                # Draw outer top border on new page
                self.page.draw_line(
                    fitz.Point(self.margin_left, self.y_pos),
                    fitz.Point(self.margin_right, self.y_pos),
                    color=(0.102, 0.212, 0.365),
                    width=2
                )
                
                # Repeat the header row on the new page
                if not is_header:
                    header_row = parsed_rows[0]
                    y_top = self.y_pos
                    y_bottom = y_top + row_height
                    
                    # Header row background
                    bg_rect = fitz.Rect(self.margin_left, y_top, self.margin_right, y_bottom)
                    self.page.draw_rect(bg_rect, color=None, fill=(0.922, 0.941, 0.965), fill_opacity=1.0)
                    
                    # Draw header row divider
                    self.page.draw_line(
                        fitz.Point(self.margin_left, y_bottom),
                        fitz.Point(self.margin_right, y_bottom),
                        color=(0.886, 0.910, 0.941),
                        width=1.5
                    )
                    
                    # Populate header cell content
                    for c_idx, cell_text in enumerate(header_row):
                        if c_idx >= num_cols:
                            break
                        x_left = self.margin_left + (c_idx * col_width)
                        x_right = x_left + col_width
                        cell_rect = fitz.Rect(x_left + 6, y_top + 4, x_right - 6, y_bottom - 2)
                        self.page.insert_textbox(
                            cell_rect,
                            cell_text,
                            fontname="msjhbd",
                            fontsize=9.5,
                            color=(0.102, 0.212, 0.365),
                            align=1 # Center aligned
                        )
                    self.y_pos += row_height
            
            y_top = self.y_pos
            y_bottom = y_top + row_height
            
            # Row background
            bg_rect = fitz.Rect(self.margin_left, y_top, self.margin_right, y_bottom)
            if is_header:
                self.page.draw_rect(bg_rect, color=None, fill=(0.922, 0.941, 0.965), fill_opacity=1.0)
            elif r_idx % 2 == 1:
                self.page.draw_rect(bg_rect, color=None, fill=(0.976, 0.984, 0.992), fill_opacity=1.0)
                
            # Draw row dividers
            self.page.draw_line(
                fitz.Point(self.margin_left, y_bottom),
                fitz.Point(self.margin_right, y_bottom),
                color=(0.886, 0.910, 0.941),
                width=1.5 if is_header or r_idx == len(parsed_rows)-1 else 0.8
            )
            
            # Populate cell content
            for c_idx, cell_text in enumerate(row):
                if c_idx >= num_cols:
                    break
                x_left = self.margin_left + (c_idx * col_width)
                x_right = x_left + col_width
                
                cell_rect = fitz.Rect(x_left + 6, y_top + 4, x_right - 6, y_bottom - 2)
                font = "msjhbd" if is_header else "msjh"
                color = (0.102, 0.212, 0.365) if is_header else (0.176, 0.216, 0.282)
                
                self.page.insert_textbox(
                    cell_rect,
                    cell_text,
                    fontname=font,
                    fontsize=9.5 if is_header else 9,
                    color=color,
                    align=1 # Center aligned
                )
                
            self.y_pos += row_height
            
        self.y_pos += 16

    def save(self):
        page_count = self.doc.page_count
        for idx in range(page_count):
            p = self.doc[idx]
            
            # Header
            if self.header_text:
                p.draw_line(
                    fitz.Point(self.margin_left, 45),
                    fitz.Point(self.margin_right, 45),
                    color=(0.886, 0.910, 0.941),
                    width=1
                )
                p.insert_text(
                    fitz.Point(self.margin_left, 38),
                    self.header_text,
                    fontname="msjh",
                    fontsize=8.5,
                    color=(0.443, 0.502, 0.588)
                )
                
            # Footer
            if self.footer_text:
                p.insert_text(
                    fitz.Point(self.margin_left, self.margin_bottom + 25),
                    self.footer_text,
                    fontname="msjh",
                    fontsize=8.5,
                    color=(0.443, 0.502, 0.588)
                )
                
            # Page Number
            if self.show_page_num:
                p.insert_text(
                    fitz.Point(self.margin_right - 45, self.margin_bottom + 25),
                    f"Page {idx + 1} of {page_count}",
                    fontname="msjh",
                    fontsize=8.5,
                    color=(0.443, 0.502, 0.588)
                )
                
        self.doc.save(self.output_path, garbage=4, deflate=True)
        self.doc.close()
        print(f"🎉 乾淨的 PDF 已成功儲存至: {self.output_path}")

def parse_markdown_to_blocks(md_content):
    blocks = []
    lines = md_content.splitlines()
    
    in_code_block = False
    code_buffer = []
    
    in_table = False
    table_buffer = []
    
    for line in lines:
        stripped = line.strip()
        
        # Code blocks
        if stripped.startswith("```"):
            if in_code_block:
                blocks.append(('code', "\n".join(code_buffer)))
                code_buffer = []
                in_code_block = False
            else:
                # Flush table if exists
                if in_table:
                    blocks.append(('table', table_buffer))
                    table_buffer = []
                    in_table = False
                in_code_block = True
            continue
            
        if in_code_block:
            code_buffer.append(line)
            continue
            
        # Tables
        if stripped.startswith("|") and stripped.endswith("|"):
            # Ignore markdown separator line
            if re.match(r"^\|[\s:-|]+\|$", stripped):
                continue
            if not in_table:
                in_table = True
            table_buffer.append(line)
            continue
        else:
            if in_table:
                blocks.append(('table', table_buffer))
                table_buffer = []
                in_table = False
                
        if not stripped:
            continue
            
        # Headers
        if stripped.startswith("# "):
            blocks.append(('h1', clean_markdown_formatting(stripped[2:])))
        elif stripped.startswith("## "):
            blocks.append(('h2', clean_markdown_formatting(stripped[3:])))
        elif stripped.startswith("### "):
            blocks.append(('h3', clean_markdown_formatting(stripped[4:])))
        # Blockquotes / Alerts
        elif stripped.startswith(">"):
            quote_text = stripped[1:].strip()
            # Clean alert syntax [!IMPORTANT]
            alert_match = re.match(r"^\[!(IMPORTANT|NOTE|TIP|WARNING|CAUTION)\](.*)", quote_text, re.IGNORECASE)
            if alert_match:
                alert_type = alert_match.group(1).upper()
                body = alert_match.group(2).strip()
                title_map = {
                    "IMPORTANT": "【重要說明】",
                    "NOTE": "【注意事項】",
                    "TIP": "【實用提示】",
                    "WARNING": "【警示說明】",
                    "CAUTION": "【警告】"
                }
                title = title_map.get(alert_type, "【提示】")
                quote_text = f"{title}\n{body}"
            blocks.append(('quote', clean_markdown_formatting(quote_text)))
        # Lists
        elif stripped.startswith("- ") or stripped.startswith("* "):
            blocks.append(('bullet', clean_markdown_formatting(stripped[2:])))
        elif re.match(r"^\d+\.\s", stripped):
            match = re.match(r"^\d+\.\s(.*)", stripped)
            blocks.append(('bullet', clean_markdown_formatting(match.group(1))))
        else:
            # Paragraph
            blocks.append(('p', clean_markdown_formatting(stripped)))
            
    # Flush remaining table
    if in_table:
        blocks.append(('table', table_buffer))
        
    return blocks

def main():
    parser = argparse.ArgumentParser(description="Markdown to beautifully compiled PDF report converter.")
    parser.add_argument("input_md", help="Path to input Markdown file.")
    parser.add_argument("output_pdf", help="Path to output PDF file.")
    parser.add_argument("--header", default="", help="Custom header text for every page.")
    parser.add_argument("--footer", default="", help="Custom footer text for every page.")
    parser.add_argument("--font", default=REG_FONT_PATH, help="Path to customized TTF/TTC font file.")
    parser.add_argument("--margin-left", type=int, default=50, help="Left margin in pixels.")
    parser.add_argument("--margin-right", type=int, default=545, help="Right margin in pixels.")
    parser.add_argument("--margin-top", type=int, default=60, help="Top margin in pixels.")
    parser.add_argument("--margin-bottom", type=int, default=780, help="Bottom margin in pixels.")
    parser.add_argument("--no-page-num", action="store_true", help="Disable drawing page numbers.")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input_md):
        print(f"❌ Error: Input Markdown file does not exist: {args.input_md}", file=sys.stderr)
        sys.exit(1)
        
    # Ensure output directory exists
    out_dir = os.path.dirname(os.path.abspath(args.output_pdf))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
        
    with open(args.input_md, "r", encoding="utf-8", errors="ignore") as f:
        md_content = f.read()
        
    blocks = parse_markdown_to_blocks(md_content)
    
    renderer = PDFRenderer(
        output_path=args.output_pdf,
        font_path=args.font,
        margin_left=args.margin_left,
        margin_right=args.margin_right,
        margin_top=args.margin_top,
        margin_bottom=args.margin_bottom,
        header=args.header,
        footer=args.footer,
        show_page_num=not args.no_page_num
    )
    
    for b_type, data in blocks:
        if b_type == 'table':
            renderer.add_table_block(data)
        else:
            renderer.add_text_block(data, b_type)
            
    renderer.save()
    sys.exit(0)

if __name__ == "__main__":
    main()

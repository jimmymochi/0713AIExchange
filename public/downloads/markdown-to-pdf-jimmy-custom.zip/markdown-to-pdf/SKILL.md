---
name: markdown-to-pdf
description: >-
  Compiles any Markdown document into highly styled PDF reports, featuring custom grid table rendering, LaTeX-to-Unicode conversion, and alert box formatting.
---

# Markdown-to-PDF compiler (markdown-to-pdf)

本技能是一個功能強大且專為排版設計的 **Markdown 轉 PDF 編譯器 (markdown-to-pdf)**。它封裝了高精度的 PDF 幾何排版引擎，並內建了三大防亂碼核心處理模組，能夠將任何複雜的 Markdown 技術文件編譯為完美排版且乾淨無噪聲的 PDF 報告。

---

## 核心特性與防亂碼引擎

1. **LaTeX 數學公式 Unicode 清理引擎**：
   自動將 Markdown 中的 LaTeX 定界符（`$$` 與 `$$）以及複雜語法（如 `\phi`、`\circ`、`\bmod`）轉換為乾淨對齊的 Unicode 符號，徹底避免在 PDF 中出現程式碼堆疊和乱碼。
2. **Markdown 表格網格化渲染引擎**：
   自動將 Markdown 中的表格語法解析並在 PDF 中以圖形化的表格網格、背景交替色塊與對齊填色區域進行重繪，完全清除 `|`、`-` 等管道與間隔噪聲。
3. **Alert 提示框（例如 `> [!IMPORTANT]`）智慧美化**：
   智慧型轉換並消除 GitHub 風格的 Alert 語法，為其配置精美的「【重要說明】」、「【注意事項】」中文字頭，並畫出垂直灰色邊線和淡色背景包圍。
4. **自訂控制參數**：
   支援在命令行自訂指定頁首、頁尾、頁碼開關、上下左右邊距及自訂繁體中文字型路徑。

---

## 依賴需求

本技能依賴本地端 Python 環境中的 `PyMuPDF` (fitz) 套件。
如果本機尚未安裝，請在 Terminal 中執行：
```powershell
pip install PyMuPDF
```

---

## 快速使用指南 (Quick Start)

### 1. 執行標準編譯（預設高質感風格）
在 Terminal 中執行以下命令，將本地的 Markdown 檔案編譯為 PDF：
```powershell
py C:\Users\jimmy\.gemini\config\plugins\science\skills\markdown-to-pdf\scripts\convert.py "C:\input.md" "C:\output.pdf"
```

### 2. 加上自訂頁首、頁尾與字型參數
```powershell
py C:\Users\jimmy\.gemini\config\plugins\science\skills\markdown-to-pdf\scripts\convert.py "C:\input.md" "C:\output.pdf" `
  --header "台北市立大學 地球環境暨生物資源學系" `
  --footer "授課教師：陳達毅" `
  --font "C:\Windows\Fonts\msjh.ttc"
```

---

## 命令行參數說明 (CLI Options)

| 參數 | 說明 | 預設值 |
| :---: | :--- | :---: |
| `input_md` | **必填參數**。輸入的 Markdown 文件路徑。 | *無* |
| `output_pdf` | **必填參數**。輸出的 PDF 報告儲存路徑。 | *無* |
| `--header` | 每頁頁眉頂部的自訂說明文字。 | `""` (空) |
| `--footer` | 每頁頁腳底部的自訂說明文字。 | `""` (空) |
| `--font` | 使用的系統 TrueType / OpenType 字型檔案路徑。 | `C:\Windows\Fonts\msjh.ttc` (微軟正黑體) |
| `--margin-left` | PDF 頁面的左邊距（像素）。 | `50` |
| `--margin-right`| PDF 頁面的右邊距（像素）。 | `545` |
| `--margin-top` | PDF 頁面的上邊距（像素）。 | `60` |
| `--margin-bottom`| PDF 頁面的下邊距（像素）。 | `780` |
| `--no-page-num`| 禁用在頁面右下角繪製「Page X of Y」頁碼。 | *未啟用* |

---

## 常見錯誤排除 (Common Mistakes)

1. **表格寬度過窄溢出**：
   如果您的表格欄位過多，等寬分割的儲存格可能會使文字換行。建議適當調整左右邊距（例如 `--margin-left 30 --margin-right 565`）以拓寬繪製範圍。
2. **非數位原生 Markdown（包含嵌入圖片）**：
   本 PDF 引擎主要渲染文字、代碼、列表與表格。Markdown 中直接嵌入的網頁圖片鏈接將不會在 PDF 中自動繪製。
